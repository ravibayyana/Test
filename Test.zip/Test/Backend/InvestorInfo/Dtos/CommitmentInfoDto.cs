namespace InvestorInfo.Dtos;

public class CommitmentInfoDto
{
    public string InvestorName { get; set; } = string.Empty;
    public string InvestorType { get; set; } = string.Empty;
    public string AssetClassName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = string.Empty;
}