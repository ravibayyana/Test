﻿namespace InvestorInfo.Dtos;
public class InvestorInfoDto
{
    public int InvestorTypeId { get; set; }
    public string InvestorName { get; set; } = string.Empty;
    public string InvestorType { get; set; } = string.Empty;
    public decimal TotalCommitments { get; set; }
    public string Address { get; set; }
}