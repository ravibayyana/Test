using InvestorInfo.Dtos;
using InvestorInfo.Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;

[ApiController]
//[Route("[controller]")]
[Route("")]
public class InvestorsController : ControllerBase
{
    private readonly IInvestorRepository _repository;
    private readonly IMemoryCache _cache;
    private readonly ILogger<InvestorsController> _logger;
    const string InvestorInfoKey = "InvestorInfo";

    public InvestorsController(IInvestorRepository repository, IMemoryCache cache, ILogger<InvestorsController> logger)
    {
        _repository = repository;
        _cache = cache;
        _logger = logger;
    }

    [HttpPost("SeedDb")]
    public async Task<ActionResult<bool>> SeedDb()
    {
        try
        {
            await _repository.SeedDbAsync();
            return Ok(true);
        }
        catch (Exception e)
        {
            return NotFound($"Failed to clear data from all tables. Error: {e.Message}, {e.StackTrace}");
        }
    }

    [HttpPost("ClearDBData")]
    public async Task<ActionResult<bool>> ClearAllData()
    {
        try
        {
            await _repository.ClearDataAsync();
            return Ok(true);
        }
        catch (Exception e)
        {
            return NotFound($"Failed to clear data from all tables. Error: {e.Message}, {e.StackTrace}");
        }
    }

    [HttpGet("GetInvestors")]
    public async Task<ActionResult<List<InvestorInfoDto>>> GetInvestorsInfo()
    {
        try
        {
            if (_cache.TryGetValue(InvestorInfoKey, out List<InvestorInfoDto> investorInfos))
            {
                return Ok(investorInfos);
            }

            var investors = await _repository.GetInvestorsInfoAsync();
            _cache.Set(InvestorInfoKey, investors);
            return Ok(investors);
        }
        catch (Exception e)
        {
            return NotFound($"No Investors found. Error: {e.Message}, {e.StackTrace}");
        }
    }

    [HttpGet("GetCommitments/{investorName}/{investorType}")]
    public async Task<ActionResult<List<CommitmentInfoDto>>> GetCommitmentsInfo(string investorName, string investorType)
    {
        try
        {
            var key = GetInvestorCommitmentKey(investorName, investorType);

            if (_cache.TryGetValue(key, out List<CommitmentInfoDto> investorInfos))
            {
                return Ok(investorInfos);
            }

            var results = await _repository.GetInvestorCommitmentsInfoAsync(investorName, investorType);

            _cache.Set(key, results);

            return Ok(results);
        }
        catch (Exception e)
        {
            return NotFound($"No Commitments Info found for " +
                            $"investor {investorName}, {investorType}, Error: {e.Message}, {e.StackTrace}");
        }
    }

    private string GetInvestorCommitmentKey(string investorName, string investorType)
    {
        return $"{investorName}_{investorType}_Commitment".ToUpper();
    }
}
