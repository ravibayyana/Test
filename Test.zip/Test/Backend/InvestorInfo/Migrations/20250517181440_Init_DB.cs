﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace InvestorInfo.Migrations
{
    /// <inheritdoc />
    public partial class Init_DB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AssetClasses",
                columns: table => new
                {
                    AssetClassId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssetClasses", x => x.AssetClassId);
                });

            migrationBuilder.CreateTable(
                name: "InvestorTypes",
                columns: table => new
                {
                    InvestorTypeId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Type = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InvestorTypes", x => x.InvestorTypeId);
                });

            migrationBuilder.CreateTable(
                name: "Investors",
                columns: table => new
                {
                    InvestorName = table.Column<string>(type: "TEXT", nullable: false),
                    InvestorTypeId = table.Column<int>(type: "INTEGER", nullable: false),
                    Country = table.Column<string>(type: "TEXT", nullable: false),
                    DateAdded = table.Column<DateTime>(type: "TEXT", nullable: false),
                    LastUpdated = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Investors", x => new { x.InvestorName, x.InvestorTypeId });
                    table.ForeignKey(
                        name: "FK_Investors_InvestorTypes_InvestorTypeId",
                        column: x => x.InvestorTypeId,
                        principalTable: "InvestorTypes",
                        principalColumn: "InvestorTypeId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Commitments",
                columns: table => new
                {
                    CommitmentId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    InvestorName = table.Column<string>(type: "TEXT", nullable: false),
                    InvestorTypeId = table.Column<int>(type: "INTEGER", nullable: false),
                    AssetClassId = table.Column<int>(type: "INTEGER", nullable: false),
                    Amount = table.Column<decimal>(type: "TEXT", nullable: false),
                    Currency = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Commitments", x => x.CommitmentId);
                    table.ForeignKey(
                        name: "FK_Commitments_AssetClasses_AssetClassId",
                        column: x => x.AssetClassId,
                        principalTable: "AssetClasses",
                        principalColumn: "AssetClassId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Commitments_Investors_InvestorName_InvestorTypeId",
                        columns: x => new { x.InvestorName, x.InvestorTypeId },
                        principalTable: "Investors",
                        principalColumns: new[] { "InvestorName", "InvestorTypeId" },
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Commitments_AssetClassId",
                table: "Commitments",
                column: "AssetClassId");

            migrationBuilder.CreateIndex(
                name: "IX_Commitments_InvestorName_InvestorTypeId",
                table: "Commitments",
                columns: new[] { "InvestorName", "InvestorTypeId" });

            migrationBuilder.CreateIndex(
                name: "IX_Investors_InvestorTypeId",
                table: "Investors",
                column: "InvestorTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Commitments");

            migrationBuilder.DropTable(
                name: "AssetClasses");

            migrationBuilder.DropTable(
                name: "Investors");

            migrationBuilder.DropTable(
                name: "InvestorTypes");
        }
    }
}
