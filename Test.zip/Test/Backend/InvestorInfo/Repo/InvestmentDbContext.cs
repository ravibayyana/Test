﻿using InvestorInfo.Repo.Entities;
using Microsoft.EntityFrameworkCore;

namespace InvestorInfo.Repo;

public class InvestmentDbContext : DbContext
{
    public DbSet<Investor> Investors { get; set; }
    public DbSet<InvestorType> InvestorTypes { get; set; }
    public DbSet<AssetClass> AssetClasses { get; set; }
    public DbSet<Commitment> Commitments { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        //modelBuilder.Entity<Investor>()
        //    .Property(i => i.UniqueId)
        //    .ValueGeneratedOnAdd();

        modelBuilder.Entity<Investor>()
            .HasKey(c => new { c.InvestorName, c.InvestorTypeId }); //Composite key

        modelBuilder.Entity<Commitment>()
            .HasOne(c => c.Investor)
            .WithMany(i => i.Commitments)
            .HasForeignKey(c => new { c.InvestorName, c.InvestorTypeId });

        modelBuilder.Entity<Commitment>()
            .HasOne(c => c.AssetClass)
            .WithMany(a => a.Commitments)
            .HasForeignKey(c => c.AssetClassId);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=investment.db");
        optionsBuilder.EnableSensitiveDataLogging();
    }
}