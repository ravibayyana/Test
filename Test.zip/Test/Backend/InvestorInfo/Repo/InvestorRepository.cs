using InvestorInfo.Dtos;
using Microsoft.EntityFrameworkCore;

namespace InvestorInfo.Repo;

public class InvestorRepository : IInvestorRepository
{
    const string SeedDataPath = @"Repo\SeedData\data.csv";

    public async Task<bool> SeedDbAsync()
    {
        var context = new InvestmentDbContext();
        await ClearDataAsync();
        await DbSeederHelper.SeedData(context, SeedDataPath);

        return true;
    }

    public async Task<bool> ClearDataAsync()
    {
        var context = new InvestmentDbContext();

        context.Investors.RemoveRange(context.Investors.ToList());
        context.AssetClasses.RemoveRange(context.AssetClasses.ToList());
        context.Commitments.RemoveRange(context.Commitments.ToList());
        context.InvestorTypes.RemoveRange(context.InvestorTypes.ToList());

        await context.SaveChangesAsync();

        return true;
    }

    public async Task<List<InvestorInfoDto>> GetInvestorsInfoAsync()
    {
        var context = new InvestmentDbContext();
        var investors = await context.Investors.Include(i => i.Commitments)
            .Include(investor => investor.Type)
            .ToListAsync();

        return investors.Select(i =>
            {
                return new InvestorInfoDto
                {
                    InvestorTypeId = i.InvestorTypeId,
                    InvestorName = i.InvestorName,
                    InvestorType = i.Type.Type,
                    Address = i.Country,
                    TotalCommitments = i.Commitments.Sum(c => c.Amount)
                };
            })
            .OrderBy(x => x.InvestorName)
            .ToList();
    }

    public async Task<List<CommitmentInfoDto>> GetInvestorCommitmentsInfoAsync(string investorName,
        string investorType)
    {
        return await GetCommitmentInfo(investorName, investorType);
    }

    private async Task<List<CommitmentInfoDto>> GetCommitmentInfo(string investorName,
        string investorType)
    {
        var context = new InvestmentDbContext();
        var query = context.Commitments.Include(c => c.AssetClass).Include(c => c.Investor)
            .ThenInclude(investor => investor.Type);

        return query.ToList().Where(x => x.InvestorName == investorName && x.Investor.Type.Type == investorType)
            .Select(x => new CommitmentInfoDto
            {
                InvestorName = x.InvestorName,
                AssetClassName = x.AssetClass.Name,
                InvestorType = x.Investor.Type.Type,
                Amount = x.Amount,
                Currency = x.Currency,
            })
            .ToList();

        //return results.GroupBy(x => x.InvestorName).ToDictionary(x => x.Key, x => x.ToList());
        //return results.GroupBy(x => x.InvestorName).ToDictionary(x => x.Key, x => x.ToList().Sum(x => x.Amount));
        //foreach (var grouping in results.GroupBy(x => x.Name))
        //{
        //    var totalAmount = grouping.Sum(x => x.Amount);
        //    var assetClassName = grouping.First().Name;
        //    var currency = grouping.First().Currency;

        //    Console.WriteLine($"Asset Class: {assetClassName}, Total Amount: {totalAmount}, Currency: {currency}");
        //}
    }
}