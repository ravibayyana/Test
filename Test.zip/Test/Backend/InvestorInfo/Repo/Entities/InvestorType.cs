﻿namespace InvestorInfo.Repo.Entities;

public class InvestorType
{
    public int InvestorTypeId { get; set; }
    public string Type { get; set; }
    public List<Investor> Investors { get; set; } = new();
}