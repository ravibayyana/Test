﻿using System.ComponentModel.DataAnnotations.Schema;

namespace InvestorInfo.Repo.Entities;

public class Investor
{
    //public int UniqueId { get; set; }
    public string InvestorName { get; set; }
    public int InvestorTypeId { get; set; }
    public InvestorType Type { get; set; }
    public string Country { get; set; }
    public DateTime DateAdded { get; set; }
    public DateTime LastUpdated { get; set; }

    public List<Commitment> Commitments { get; set; } = new();


    // Unique key derived from composite key
    [NotMapped]
    public string UniqueKey => $"{InvestorName}-{Type}";

}