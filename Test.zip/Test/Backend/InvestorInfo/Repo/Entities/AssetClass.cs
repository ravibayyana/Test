﻿namespace InvestorInfo.Repo.Entities;

public class AssetClass
{
    public int AssetClassId { get; set; }
    public string Name { get; set; }

    public List<Commitment> Commitments { get; set; } = new();
}