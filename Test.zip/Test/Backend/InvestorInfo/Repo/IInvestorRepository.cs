using InvestorInfo.Dtos;

namespace InvestorInfo.Repo;

public interface IInvestorRepository
{
    Task<bool> ClearDataAsync();
    Task<bool> SeedDbAsync();
    Task<List<InvestorInfoDto>> GetInvestorsInfoAsync();

    Task<List<CommitmentInfoDto>> GetInvestorCommitmentsInfoAsync(string investorName, string investorType);
}