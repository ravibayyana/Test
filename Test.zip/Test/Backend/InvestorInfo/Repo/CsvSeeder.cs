﻿using InvestorInfo.Repo.Entities;
using System.Globalization;

namespace InvestorInfo.Repo;

public class DbSeederHelper
{
    public static async Task<bool> SeedData(InvestmentDbContext context, string filePath)
    {
        if (context.Investors.Any())
            return false;

        var lines = File.ReadAllLines(filePath).Skip(1); // Skip header
        foreach (var line in lines)
        {
            var values = line.Split(',');

            var investorName = values[0].Trim();
            var investorTypeName = values[1].Trim();
            var investorCountry = values[2].Trim();
            var dateAdded = DateTime.ParseExact(values[3], "yyyy-MM-dd", CultureInfo.InvariantCulture);
            var lastUpdated = DateTime.ParseExact(values[4], "yyyy-MM-dd", CultureInfo.InvariantCulture);
            var assetClassName = values[5].Trim();
            var amount = decimal.Parse(values[6]);
            var currency = values[7].Trim();

            var investorType = context.InvestorTypes.FirstOrDefault(it => it.Type == investorTypeName);
            if (investorType == null)
            {
                context.InvestorTypes.Add(new InvestorType { Type = investorTypeName });
                await context.SaveChangesAsync();
                investorType = context.InvestorTypes.FirstOrDefault(it => it.Type == investorTypeName);
            }
                

            var investor = context.Investors.FirstOrDefault(i => i.InvestorName == investorName && i.InvestorTypeId == investorType.InvestorTypeId);
            if (investor == null)
            {
                investor = new Investor
                {
                    InvestorName = investorName,
                    InvestorTypeId = investorType.InvestorTypeId,
                    Country = investorCountry,
                    DateAdded = dateAdded,
                    LastUpdated = lastUpdated
                };
                context.Investors.Add(investor);
                await context.SaveChangesAsync();
                investor = context.Investors.FirstOrDefault(i => i.InvestorName == investorName && i.InvestorTypeId == investorType.InvestorTypeId);
            }

            var assetClass = context.AssetClasses.FirstOrDefault(ac => ac.Name == assetClassName);
            if (assetClass == null)
            {
                context.AssetClasses.Add(new AssetClass { Name = assetClassName });
                await context.SaveChangesAsync();
                assetClass = context.AssetClasses.FirstOrDefault(ac => ac.Name == assetClassName);
            }

            var commitment = new Commitment
            {
                Investor = investor,
                AssetClass = assetClass,
                Amount = amount,
                Currency = currency
            };

            // Add entities to the context
            context.Commitments.Add(commitment);
        }

        // Save changes to the database
        await context.SaveChangesAsync();
        Console.WriteLine("Data successfully seeded from the CSV file!");

        return true;
    }
}