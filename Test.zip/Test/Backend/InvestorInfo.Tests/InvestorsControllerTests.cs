using InvestorInfo.Dtos;
using InvestorInfo.Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;

namespace InvestorInfo.Tests;

public class InvestorsControllerTests
{
    private readonly Mock<IInvestorRepository> _mockRepository;
    private readonly Mock<ILogger<InvestorsController>> _mockLogger;
    private readonly IMemoryCache _memoryCache;
    private readonly InvestorsController _controller;
    public InvestorsControllerTests()
    {
        _mockRepository = new Mock<IInvestorRepository>();
        _mockLogger = new Mock<ILogger<InvestorsController>>();
        _memoryCache = new MemoryCache(new MemoryCacheOptions());
        _controller = new InvestorsController(_mockRepository.Object, _memoryCache, _mockLogger.Object);
    }

    [Fact]
    public async Task GetInvestors()
    {
        // Arrange
        
        _mockRepository.Setup(repo => repo.GetInvestorsInfoAsync())
            .ReturnsAsync([
                new() { InvestorName = "Investor A", InvestorType = "Wealth Manager" },
                new() { InvestorName = "Investor B", InvestorType = "Asset Manager" }
            ]);

        // Act
        var result = await _controller.GetInvestorsInfo();

        _mockRepository.Verify(repo => repo.GetInvestorsInfoAsync(), Times.Once);

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var investors = Assert.IsType<List<InvestorInfoDto>>(okResult.Value);
        Assert.Equal(2, investors.Count);
    }

    [Fact] public async Task GetInvestors_CalledTwice_DB_Is_Only_Called_Once()
    {
        // Arrange
        _mockRepository.Setup(repo => repo.GetInvestorsInfoAsync())
            .ReturnsAsync([
                new() { InvestorName = "Investor A", InvestorType = "Wealth Manager" },
                new() { InvestorName = "Investor B", InvestorType = "Asset Manager" }
            ]);
       
        // Act
        var result = await _controller.GetInvestorsInfo();
        result = await _controller.GetInvestorsInfo();
        result = await _controller.GetInvestorsInfo();
        result = await _controller.GetInvestorsInfo();


        _mockRepository.Verify(repo => repo.GetInvestorsInfoAsync(), Times.Once);

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var investors = Assert.IsType<List<InvestorInfoDto>>(okResult.Value);
        Assert.Equal(2, investors.Count);
    }

    [Fact]
    public async Task GetCommitmentsInfo_ReturnsDataFromCache_WhenCacheHit()
    {
        // Arrange
        var investorName = "InvestorA";
        var investorType = "Type1";
        var cacheKey = $"{investorName}_{investorType}_Commitment".ToUpper();

        var cachedData = new List<CommitmentInfoDto>()
        {
            new() { Amount = 1000 }
        };

        _memoryCache.Set(cacheKey, cachedData);

        // Act
        var result = await _controller.GetCommitmentsInfo(investorName, investorType);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var data = Assert.IsType<List<CommitmentInfoDto>>(okResult.Value);
        Assert.Equal(cachedData, data);

        // Verify repository was never called
        _mockRepository.Verify(repo => repo.GetInvestorCommitmentsInfoAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task GetCommitmentsInfo_CallsRepositoryAndCachesResult_WhenCacheMiss()
    {
        // Arrange
        var investorName = "InvestorA";
        var investorType = "Type1";
        var cacheKey = $"{investorName}_{investorType}_Commitment".ToUpper();

        var repositoryData = new List<CommitmentInfoDto>() 
        {
            new() { Amount = 1000 } 
        };

        _mockRepository.Setup(repo => repo.GetInvestorCommitmentsInfoAsync(investorName, investorType))
            .ReturnsAsync(repositoryData);

        // Act
        var result = await _controller.GetCommitmentsInfo(investorName, investorType);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var data = Assert.IsType<List<CommitmentInfoDto>>(okResult.Value);
        Assert.Equal(repositoryData, data);

        // Verify repository was called once
        _mockRepository.Verify(repo => repo.GetInvestorCommitmentsInfoAsync(investorName, investorType), Times.Once);

        // Verify data is now in cache
        Assert.True(_memoryCache.TryGetValue(cacheKey, out var cachedData));
        Assert.Equal(repositoryData, cachedData);
    }

    [Fact]
    public async Task GetCommitmentsInfo_ReturnsNotFound_WhenRepositoryThrowsException()
    {
        // Arrange
        var investorName = "InvestorA";
        var investorType = "Type1";

        _mockRepository.Setup(repo => repo.GetInvestorCommitmentsInfoAsync(investorName, investorType))
            .ThrowsAsync(new Exception("Database error"));

        // Act
        var result = await _controller.GetCommitmentsInfo(investorName, investorType);

        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result.Result);
        var errorMessage = Assert.IsType<string>(notFoundResult.Value);
        Assert.Contains("No Commitments Info found", errorMessage);
        Assert.Contains("Database error", errorMessage);

        // Verify repository was called once
        _mockRepository.Verify(repo => repo.GetInvestorCommitmentsInfoAsync(investorName, investorType), Times.Once);
    }
}