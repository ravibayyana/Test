import numeral from "numeral";

const BASEURL: string = "http://localhost:5210";
export const InvestorsURL = `${BASEURL}/GetInvestors`;
export const GetCommitmentsURL = (name: string, type: string) =>
  `${BASEURL}/GetCommitments/${name}/${type}`;
export const getBillions = (value: number) =>
  numeral(value).format(`0.0a`).toUpperCase(); // Get millions, billions, kilo
export const getBillionsWithCcy = (value: number, ccy: string = "") =>
  `${ccy}${getBillions(value)}`;
export const AllCommitments = "All";
