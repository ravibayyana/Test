export interface InvestorInfoModel {
  investorTypeId: number;
  investorName: string;
  investorType: string;
  totalCommitments: number;
  dateAdded: Date;
  address: string;
}

export interface CommitmentInfoModel {
  investorName: string;
  investorType: string;
  assetClassName: string;
  amount: number;
  currency: string;
}
