import { useCallback, useState } from "react";
import "./App.css";
import type { InvestorInfoModel } from "./models/InvestorInfoModel";
import { InvestorInfo } from "./components/InvestorInfo";
import { CommitmentsInfo } from "./components/CommitmentsInfo";

function App() {
  const [
    selectedInvestor,
    setSelectedInvestor,
  ] = useState<InvestorInfoModel | null>(null);

  const handleInvestorChanged = useCallback((investor: InvestorInfoModel) => {
    setSelectedInvestor(investor);
  }, []);

  return (
    <>
      <InvestorInfo onInvestorChanged={handleInvestorChanged} />
      {selectedInvestor && <CommitmentsInfo investor={selectedInvestor} />}
    </>
  );
}

export default App;
