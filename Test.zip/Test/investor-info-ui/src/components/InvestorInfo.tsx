"use client";
import type { ColDef } from "ag-grid-community";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { useEffect, useState } from "react";
import axios from "axios";
import moment from "moment";
import type { InvestorInfoModel } from "../models/InvestorInfoModel";
import { getBillions, InvestorsURL } from "../utils/constants";

ModuleRegistry.registerModules([AllCommunityModule]);

export interface InvestorInfoProps {
  onInvestorChanged: (x: InvestorInfoModel) => void;
}

export const InvestorInfo = (props: InvestorInfoProps) => {
  const [investors, setInvestors] = useState<InvestorInfoModel[]>([]);
  const [colDefs] = useState<ColDef<InvestorInfoModel>[]>([
    {
      field: "investorName",
      headerName: "Name",
      cellRenderer: (params: any) => {
        return (
          <div
            className="clickable"
            onClick={() => props.onInvestorChanged(params.data)}
          >
            {params.value}
          </div>
        );
      },
    },
    { field: "investorType", headerName: "Type" },
    {
      field: "dateAdded",
      headerName: "Date Added",
      valueFormatter: (params) => moment(params.value).format("MMMM Do YYYY"),
    },
    { field: "address", headerName: "Address" },
    {
      field: "totalCommitments",
      headerName: "Total Commitment",
      valueFormatter: (params) => getBillions(params.value),
    },
  ]);

  useEffect(() => {
    axios
      .get<InvestorInfoModel[]>(InvestorsURL)
      .then((response) => {
        setInvestors(response.data);
      })
      .catch((error) => console.error("Error fetching Investors Info:", error));
  }, []);

  const loading = investors.length === 0;
  const defaultColDef: ColDef = {
    flex: 1,
    sortable: false,
    suppressMovable: true,
  };

  if (loading) {
    return <h1>Loading Investor Info..............</h1>;
  }

  return (
    <>
      <h1>Investors</h1>
      <div style={{ width: "900px", height: "220px", textAlign: "center" }}>
        <AgGridReact
          rowData={investors}
          columnDefs={colDefs}
          defaultColDef={defaultColDef}
        />
      </div>
    </>
  );
};
