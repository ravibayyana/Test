'use client';
import type { ColDef } from "ag-grid-community";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { useEffect, useState } from 'react';
import axios from 'axios';
import type { CommitmentInfoModel, InvestorInfoModel } from "../models/InvestorInfoModel";
import { AllCommitments, getBillions, getBillionsWithCcy, GetCommitmentsURL } from "../utils/constants";

ModuleRegistry.registerModules([AllCommunityModule]);

export interface CommitmentsInfoProps{
  investor: InvestorInfoModel;
}

interface AssetInfo {
  name: string;
  totalAmount: number|undefined;
  ccy: string 
}

const defaultColDef: ColDef = {
        flex: 1,
        sortable: false,
        suppressMovable: true,
  };

const colDefs:ColDef<CommitmentInfoModel>[] = [
    { field: "assetClassName", headerName: 'Asset Class'},
    { field: "currency", headerName: 'Currency' },   
    { field: "amount", headerName: 'Amount', valueFormatter: params => getBillions(params.value)},
  ];
  
const assetsByName: Map<string, CommitmentInfoModel[]> = new Map<string, CommitmentInfoModel[]>;
const assetInfo: AssetInfo[] = [];

export const CommitmentsInfo = (props: CommitmentsInfoProps) => {
  const [commitments, setCommitments] = useState<CommitmentInfoModel[]>([]);
  const [selectedCommitment, setSelectedCommitments] = useState<string>("");

  useEffect(() => {
    if(!selectedCommitment)
      return;

    setCommitments(assetsByName.get(selectedCommitment)!);

   }, [selectedCommitment]);

  useEffect(() => {
    const commitmentsURL = GetCommitmentsURL(props.investor.investorName, props.investor.investorType);
    console.log(commitmentsURL);
    axios.get<CommitmentInfoModel[]>(commitmentsURL)
      .then(response => {
        setCommitments(response.data);
        assetsByName.clear();
        assetInfo.length = 0;

        assetsByName.set(AllCommitments, response.data);
        response.data.forEach(d=> {
          if(assetsByName.has(d.assetClassName)) {
            assetsByName.get(d.assetClassName)?.push(d);
          }
          else{
            assetsByName.set(d.assetClassName, [d]);
          }
        })

        Array.from(assetsByName.keys()).forEach(key => {
          const asset :AssetInfo = {name: key, ccy: assetsByName.get(key)![0].currency,  totalAmount: assetsByName.get(key)?.reduce((sum, c) => sum + c.amount, 0)}
          assetInfo.push(asset);
        });
        setSelectedCommitments(AllCommitments);
    })
      .catch(error => console.error('Error fetching Commitments Info:', error));
  }, [props.investor]);

  const loading = commitments.length === 0;
  if(loading){
    return <h1>Loading Commitments Info..............</h1>
  }

  const getFilters = () => {
    const filters  = assetInfo.sort((x, y) => x.name.localeCompare(y.name)).map(a => {
      const isSelected = a.name === selectedCommitment;
      const background = isSelected ? "lightgreen" : "";
      return(
          <button key={a.name} style={{height: "70px", minWidth:"120px", fontWeight: "bolder", background: `${background}` }} onClick={() =>  setSelectedCommitments(a.name)}>           
            <span>{a.name}</span><br/>
            <span>{getBillionsWithCcy(a.totalAmount!, a.ccy == "GBP" ? "£": "")}</span>             
          </button>
      );
    });

    return filters;
  }

  return (
    <>
      <h1>{`Commitments of '${props.investor.investorName}'`}</h1>
       <div style={{display: "flex", gap: "10px", flexDirection: "row", marginBottom: "15px"}}>
        {getFilters()}
       </div>
      
      <div style={{ width: "900px", height: "500px", textAlign: "center" }}>
        <AgGridReact
          rowData={commitments}
          columnDefs={colDefs}
          defaultColDef={defaultColDef}
        />
      </div>
    </>
  );
};