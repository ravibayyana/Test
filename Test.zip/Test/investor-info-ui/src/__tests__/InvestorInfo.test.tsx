import { InvestorInfo } from "../components/InvestorInfo";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { server } from "../mocks/server";
import { investorInfoDataMocks } from "../mocks/handlers";
import App from "../App";

describe("InvestorInfo", () => {
  test("On Init render app", async () => {
    server.use(...investorInfoDataMocks);
    render(<App />);

    await waitFor(() => {
      expect(screen.getByText(/ravi/i)).toBeInTheDocument();
      expect(screen.getByText(/bayyana/i)).toBeInTheDocument();

      const ravi = screen.getByText(/ravi/i);
      fireEvent.click(ravi);
    });

    await waitFor(() => {
      expect(screen.getByText(/All/i)).toBeInTheDocument();

      const fund1 = screen.getAllByText(/Fund1/i);
      expect(fund1.length).toBeGreaterThan(0);

      const fund2 = screen.getAllByText(/Fund2/i);
      expect(fund2.length).toBeGreaterThan(0);
    });
  });

  // test("On InvestorInfo  loaded", async () => {
  //   server.use(...investorInfoDataMocks);
  //   render(<InvestorInfo onInvestorChanged={() => {}} />);

  //   await waitFor(() => {
  //     // screen.debug();
  //     expect(screen.getByText(/ravi/i)).toBeInTheDocument();
  //     expect(screen.getByText(/bayyana/i)).toBeInTheDocument();
  //   });
  // });

  test("On investor clicked", async () => {
    server.use(...investorInfoDataMocks);

    const mockFunction = vi.fn(() => {});
    render(<InvestorInfo onInvestorChanged={mockFunction} />);

    await waitFor(() => {
      const ravi = screen.getByText(/ravi/i);
      fireEvent.click(ravi);
    });

    expect(mockFunction).toHaveBeenCalledTimes(1);
  });
});
