import { http, HttpResponse } from "msw";
import { GetCommitmentsURL, InvestorsURL } from "../utils/constants";
import {
  CommitmentInfoModel,
  InvestorInfoModel,
} from "../models/InvestorInfoModel";

export const handlers = [];

// export const errorGetData = [
//   http.get(url, () => {
//     return HttpResponse.json(
//       {
//         message: "Failed to fetch. ",
//       },
//       { status: 500 }
//     );
//   }),
// ];

const mockInvestorInfo: InvestorInfoModel[] = [
  {
    address: "UK",
    dateAdded: new Date(),
    investorName: "Ravi",
    investorType: "Banker",
    totalCommitments: 234242322324,
    investorTypeId: 1,
  },
  {
    address: "UK",
    dateAdded: new Date(),
    investorName: "Bayyana",
    investorType: "Fund Manager",
    totalCommitments: 98777697889897,
    investorTypeId: 2,
  },
];

const mockCommitmentInfo: CommitmentInfoModel[] = [
  {
    assetClassName: "Fund1",
    investorName: "Ravi",
    investorType: "Banker",
    amount: 234242322324,
    currency: "GBP",
  },
  {
    assetClassName: "Fund2",
    investorName: "Ravi",
    investorType: "Banker",
    amount: 98777697889897,
    currency: "GBP",
  },
];

export const investorInfoDataMocks = [
  http.get(InvestorsURL, () => {
    return HttpResponse.json(mockInvestorInfo);
  }),

  http.get(GetCommitmentsURL("Ravi", "Banker"), () => {
    return HttpResponse.json(mockCommitmentInfo);
  }),
];
